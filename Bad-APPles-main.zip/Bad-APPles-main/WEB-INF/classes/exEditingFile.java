import java.io.*;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;

@WebServlet("/Update")
public class Update extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // reader for user input
        InputStream reader = request.getInputStream();

        // files
        String[] fileNames = {"Uber-Jan-Feb-FOIL", "other-Dial7_B00887",
                              "other-Firstclass_B01536", "uber-raw-data-apr14"};

         // parameters from client
        String fileParam = request.getParameter("param1");
        String rowParam = request.getParameter("param2");
        String columnParam = request.getParameter("param3");
        String valueParam = request.getParameter("param4");

        // convert necessary parameters to ints
        int fileNum = Integer.parseInt(fileParam);
        int row = Integer.parseInt(fileParam);
        int column = Integer.parseInt(fileParam);

        String newFile = fileNames[fileNum] + ".csv";

        // create file and load into dataList
        File tempFile = new File("webapps/BadAPPles/temp/" + newFile);
        InputStream inputStream = new FileInputStream(tempFile);
        CSVFile csvFile = new CSVFile(inputStream);
        List<String[]> csvList = csvFile.read();
        DataList data = new DataList(csvList);

        // update 
        data.update(row, column, valueParam);

        // write the dataList to the backup
        csvFile.write(data.getData(), "webapps/BadAPPles/temp/" + newFile);

// SPRINT 6
        if top3HoursCache.java exists {
        
            update the count
                
        } // else do nothing
        

    }
}

//  javac -Xlint CSVFile.java DataList.java -cp ../../../../lib/servlet-api.jar Update.java
